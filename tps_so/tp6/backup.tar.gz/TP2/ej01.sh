#!/bin/bash

echo "Estoy aprendiendo lenguaje scripting"
